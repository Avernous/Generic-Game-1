package Swaggernaut;

/**
 * 
 * @author ShaeoSindee
 *
 */

import javax.swing.*;
import java.awt.*;

public class GUImanager {

	public static void main(String[] cheese) {

		new testPane();

	}
}
