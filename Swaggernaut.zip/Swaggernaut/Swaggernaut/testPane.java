package Swaggernaut;

import java.awt.*;
import javax.swing.*;
import javax.imageio.ImageIO;

public class testPane {

	private JFrame f;
	private JPanel p;
	private JButton b1;
	private JButton b2;
	private JButton b3;

	private JLabel lab;
	private JLabel label1;

	public testPane() {
		gui();
	}

	public void gui() {
		f = new JFrame("Swaggernaut");
		f.setResizable(false);

		f.setSize(800, 800);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		p = new JPanel(new GridBagLayout());
		p.setBackground(Color.WHITE);

		b1 = new JButton("Test Button 1");
		b2 = new JButton("Test Button 2");
		b3 = new JButton("Test Button 3");

		GridBagConstraints c = new GridBagConstraints();

		ImageIcon icon = createImageIcon("Terrain/Grass.jpg", "suck it microsoft");

		label1 = new JLabel(icon, JLabel.CENTER);

		p.add(label1);
		p.add(b1);
		p.add(b2);
		p.add(b3);
		f.add(p);

		f.setVisible(true);
	}

	// for tiling the background
	protected void tileBackground(ImageIcon icon) {
		int width = 800;
		int height = 800;
		int imageW = 50;
		int imageH = 50;

		// Tile the image to fill our area.
		for (int x = 0; x < width; x += imageW) {
			for (int y = 0; y < height; y += imageH) {
				ImageIcon temp = createImageIcon("Terrain/Grass.jpg", "");
			}
		}
	}

	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path, String description) {
		java.net.URL imgURL = getClass().getResource(path);
		if (imgURL != null) {
			return new ImageIcon(imgURL, description);
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}
}
