package Swaggernaut;

/**
 * @author Isaiah Lee Generates a special Actor Object the player can control
 *
 */

public class CharacterCreation {
	public static void main(String[] cheese) {
		GameInit.main(cheese);

		Actor a = new Actor();
	}
}
